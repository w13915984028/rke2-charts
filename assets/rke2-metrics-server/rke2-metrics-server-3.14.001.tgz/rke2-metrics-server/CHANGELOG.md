# Metrics Server Helm Chart Changelog

> [!NOTE]
> All notable changes to this project will be documented in this file; the format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

<!--
### Added - For new features.
### Changed - For changes in existing functionality.
### Deprecated - For soon-to-be removed features.
### Removed - For now removed features.
### Fixed - For any bug fixes.
### Security - In case of vulnerabilities.
-->

## [UNRELEASED]

## [3.14.0] - TBC

### Added

- Add chart option to permit setting hostUsers for additional isolation. ([#1751](https://github.com/kubernetes-sigs/metrics-server/pull/1751)) @jcpunk
- Add `namespaceOverride` which allows deploying to a namespace other than `.Release.namespace`. ([#1711](https://github.com/kubernetes-sigs/metrics-server/pull/1711)) @TheRealNoob

### Changed

- Apply `tls.certManager.annotations` and `tls.certManager.labels` to the Cert Manager `Certificate` resource; these values are documented but were previously never rendered. ([#1825](https://github.com/kubernetes-sigs/metrics-server/pull/1825)) @yugstar
- Use `metrics-server.fullname` instead of `metrics-server.name` for ClusterRole. ([#1801](https://github.com/kubernetes-sigs/metrics-server/pull/1801)) @yesdeepakverma
- Update the _Metrics Server_ OCI image to [`0.9.0`](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.9.0). ([#1846](https://github.com/kubernetes-sigs/metrics-server/pull/1846)) @stevehipwell

### Fixed

- Stop rendering `annotations: null` on the cert-manager `Issuer`, which referenced an undefined `additionalAnnotations` value. This mirrors the earlier APIService fix and prevents permanent GitOps `OutOfSync`. ([#1825](https://github.com/kubernetes-sigs/metrics-server/pull/1825)) @yugstar

## [3.13.1] - 2026-06-11

### Changed

- Update the _Metrics Server_ OCI image to [`0.8.1`](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.8.1). ([#1770](https://github.com/kubernetes-sigs/metrics-server/pull/1770)) _@stevehipwell_

### Fixed

- Conditionally render `insecureSkipTLSVerify` field in APIService template to prevent GitOps sync drift when value is `false`. ([#1727](https://github.com/kubernetes-sigs/metrics-server/pull/1727)) _@pawl_
- Do not render annotations as null in APIService template to prevent permanent OutOfSync in ArgoCD. ([#1752](https://github.com/kubernetes-sigs/metrics-server/pull/1752)) _@Serializator_

## [3.13.0] - 2025-07-22

### Added

- Add chart options to secure the connection between Metrics Server and the Kubernetes API Server. ([#1288](https://github.com/kubernetes-sigs/metrics-server/pull/1288)) _@mkilchhofer_
- Add `unhealthyPodEvictionPolicy` to the Metrics Server PDB as a user enabled feature. ([#1574](https://github.com/kubernetes-sigs/metrics-server/pull/1574)) @peterabarr

### Changed

- Update the _Addon Resizer_ OCI image to [`1.8.23`](https://github.com/kubernetes/autoscaler/releases/tag/addon-resizer-1.8.23). ([#1626](https://github.com/kubernetes-sigs/metrics-server/pull/1626)) _@stevehipwell_
- Update the _Metrics Server_ OCI image to [`0.8.0`](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.8.0). ([#1683](https://github.com/kubernetes-sigs/metrics-server/pull/1683)) _@stevehipwell_

## [3.12.2] - 2024-10-07

### Added

- Explicitly added the app protocol to the service. ([#1540](https://github.com/kubernetes-sigs/metrics-server/pull/1540)) _@
seankhliao_

### Changed

- Updated the _Metrics Server_ OCI image to [v0.7.2](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.7.2). ([#1568](https://github.com/kubernetes-sigs/metrics-server/pull/1568)) _@stevehipwell_
- Updated the _addonResizer_ OCI image to [1.8.21](https://github.com/kubernetes/autoscaler/releases/tag/addon-resizer-1.8.21). ([#1504](https://github.com/kubernetes-sigs/metrics-server/pull/1504)) _@jimmy-ungerman_

### Fixed

- Fixed nanny's RoleBinding which contained a hard-coded namespace instead of the Helm's release namespace. ([#1479](https://github.com/kubernetes-sigs/metrics-server/pull/1479)) _@the-technat_
- Fixed the `ServiceMonitor` job label. ([#1568](https://github.com/kubernetes-sigs/metrics-server/pull/1568)) _@stevehipwell_

## [3.12.1] - 2024-04-05

### Changed

- Updated the _Metrics Server_ OCI image to [v0.7.1](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.7.1). ([#1461](https://github.com/kubernetes-sigs/metrics-server/pull/1461)) _@stevehipwell_
- Changed `Deployment` templating to ignore `schedulerName` when value is empty. ([#1475](https://github.com/kubernetes-sigs/metrics-server/pull/1475)) _@senges_

## [3.12.0] - 2024-02-07

### Changed

- Updated the _Metrics Server_ OCI image to [v0.7.0](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.7.0). ([#1414](https://github.com/kubernetes-sigs/metrics-server/pull/1414)) [@stevehipwell](https://github.com/stevehipwell)
- Updated the _addon-resizer_ OCI image to [v1.8.20](https://github.com/kubernetes/autoscaler/releases/tag/addon-resizer-1.8.20). ([#1414](https://github.com/kubernetes-sigs/metrics-server/pull/1414)) [@stevehipwell](https://github.com/stevehipwell)

## [3.11.0] - 2023-08-03

### Added

- Added default _Metrics Server_ resource requests.

### Changed

- Updated the _Metrics Server_ OCI image to [v0.6.4](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.6.4).
- Updated the _addon-resizer_ OCI image to [v1.8.19](https://github.com/kubernetes/autoscaler/releases/tag/addon-resizer-1.8.19).

## [3.10.0] - 2023-04-12

### Added

- Added support for running under PodSecurity restricted.

### Fixed

- Fixed `auth-reader` role binding namespace to always use `kube-system`.
- Fixed addon-resizer configuration.
- Fixed container port default not having been updated to `10250`.

## [3.9.0] - 2023-03-28

### Added

- Added autoscaling support via the addon-resizer.

### Changed

- Updated the _Metrics Server_ OCI image to [v0.6.3](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.6.3).

### Fixed

- Fixed service labels/annotations.

## [3.8.4] - 2023-03-06

### Changed

- Changed the image registry location to `registry.k8s.io`.

## [3.8.3] - 2022-12-08

### Added

- Added support for topologySpreadConstraints.
- Always set resource namespaces explicitly.
- Allow configuring TLS on the APIService.
- Enabled service monitor relabelling.
- Added ability to set the scheduler name.
- Added support for common labels.

### Changed

- Updated the _Metrics Server_ OCI image to [v0.6.2](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.6.2).

## [3.8.2] - 2022-02-23

### Changed

- Changed chart to allow probes to be turned off completely (this is not advised unless you know what you're doing).

## [3.8.1] - 2022-02-09

### Changed

- Updated the _Metrics Server_ OCI image to [v0.6.1](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.6.1).

## [3.8.0] - 2022-02-08

### Added

- Added support for unauthenticated access to the /metrics endpoint.
- Added optional _Prometheus Operator_ `ServiceMonitor`.

### Changed

- Updated the _Metrics Server_ OCI image to [v0.6.0](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.6.0).

## [3.7.0] - 2021-11-18

### Changed

- Updated the _Metrics Server_ OCI image to [v0.5.2](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.5.2).

## [3.6.0] - 2021-10-18

### Added

- Added new `defaultArgs`` value to enable overriding the default arguments.

### Changed

- Updated the _Metrics Server_ OCI image to [v0.5.1](https://github.com/kubernetes-sigs/metrics-server/releases/tag/v0.5.1).

## [3.5.0] - 2021-10-07

### Added

- Added initial Helm chart release from official repo.

<!--
RELEASE LINKS
-->
[UNRELEASED]: https://github.com/kubernetes-sigs/metrics-server/tree/master/charts/metrics-server
[3.14.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.14.0
[3.13.1]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.13.1
[3.13.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.13.0
[3.12.2]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.12.2
[3.12.1]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.12.1
[3.12.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.12.0
[3.11.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.11.0
[3.10.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.10.0
[3.9.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.9.0
[3.8.4]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.8.4
[3.8.3]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.8.3
[3.8.2]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.8.2
[3.8.1]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.8.1
[3.8.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.8.0
[3.7.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.7.0
[3.6.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.6.0
[3.5.0]: https://github.com/kubernetes-sigs/metrics-server/releases/tag/metrics-server-helm-chart-3.5.0
